# launcher.py - ЛАУНЧЕР ДЛЯ GITHUB
import tkinter as tk
from tkinter import ttk, messagebox
import os
import zipfile
import shutil
import threading
import subprocess
import urllib.request
import json
import re
import time

class GameLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("NR Studio - The Unbroken")
        self.root.geometry("1000x650")
        self.root.configure(bg='#1a1a1a')
        
        # GitHub репозиторий
        self.repo_owner = "gplyno"
        self.repo_name = "the-unbroken"
        self.branch = "main"  # или master, смотря какая ветка
        
        # API для получения списка файлов
        self.api_url = f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/contents/?ref={self.branch}"
        
        # Пути
        self.launcher_dir = os.path.dirname(os.path.abspath(__file__))
        self.game_folder = os.path.join(self.launcher_dir, "TheUnbroken")
        self.downloads_folder = os.path.join(self.launcher_dir, "downloads")
        
        os.makedirs(self.game_folder, exist_ok=True)
        os.makedirs(self.downloads_folder, exist_ok=True)
        
        # Список версий
        self.versions = []  # список кортежей (версия, название_файла, download_url)
        self.selected_version = None
        self.downloading = False
        
        # Текущая версия
        self.version_file = os.path.join(self.launcher_dir, "current_version.txt")
        self.current_version = self.load_current_version()
        
        self.setup_ui()
        self.check_game()
        
        # Автоматически загружаем список файлов
        self.root.after(1000, self.load_files_from_github)
    
    def load_current_version(self):
        try:
            if os.path.exists(self.version_file):
                with open(self.version_file, 'r') as f:
                    return f.read().strip()
        except:
            pass
        return "Не установлена"
    
    def save_current_version(self, version):
        try:
            with open(self.version_file, 'w') as f:
                f.write(version)
        except:
            pass
    
    def setup_ui(self):
        # Верхняя панель
        top = tk.Frame(self.root, bg='#2a2a2a', height=80)
        top.pack(fill='x')
        top.pack_propagate(False)
        
        tk.Label(top, text="NR STUDIO", font=('Arial', 24, 'bold'),
                fg='#ff6b6b', bg='#2a2a2a').pack(side='left', padx=20, pady=20)
        
        # Основной контейнер
        main = tk.Frame(self.root, bg='#1a1a1a')
        main.pack(expand=True, fill='both', padx=30, pady=20)
        
        # ЛЕВАЯ ЧАСТЬ - информация
        left_frame = tk.Frame(main, bg='#2a2a2a', width=500)
        left_frame.pack(side='left', fill='both', expand=True, padx=(0,10))
        
        # Баннер
        banner = tk.Frame(left_frame, bg='#3a3a3a', height=150)
        banner.pack(fill='x')
        banner.pack_propagate(False)
        
        tk.Label(banner, text="THE UNBROKEN", font=('Arial', 28, 'bold'),
                fg='#ff6b6b', bg='#3a3a3a').pack(expand=True)
        
        # Контент
        content = tk.Frame(left_frame, bg='#2a2a2a')
        content.pack(fill='both', expand=True, padx=20, pady=20)
        
        tk.Label(content, text="The Unbroken", font=('Arial', 24, 'bold'),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        
        self.current_version_label = tk.Label(content, 
            text=f"Текущая версия: {self.current_version}",
            font=('Arial', 12), fg='#888888', bg='#2a2a2a')
        self.current_version_label.pack(anchor='w', pady=5)
        
        self.game_status_label = tk.Label(content, text="Проверка...",
            font=('Arial', 12), fg='#888888', bg='#2a2a2a')
        self.game_status_label.pack(anchor='w', pady=5)
        
        self.play_btn = tk.Button(content, text="ИГРАТЬ",
            font=('Arial', 16, 'bold'), bg='#4CAF50', fg='white',
            padx=40, pady=10, bd=0, command=self.play_game, state='disabled')
        self.play_btn.pack(anchor='w', pady=20)
        
        # ПРАВАЯ ЧАСТЬ - список версий
        right_frame = tk.Frame(main, bg='#2a2a2a', width=400)
        right_frame.pack(side='right', fill='both', padx=(10,0))
        right_frame.pack_propagate(False)
        
        tk.Label(right_frame, text="ДОСТУПНЫЕ ВЕРСИИ",
                font=('Arial', 16, 'bold'), fg='#ff6b6b',
                bg='#2a2a2a').pack(pady=15)
        
        # Статус подключения
        self.connection_label = tk.Label(right_frame, text="🌐 Подключение к GitHub...",
                                         fg='#ffaa00', bg='#2a2a2a', font=('Arial', 9))
        self.connection_label.pack(pady=5)
        
        # Список версий
        list_frame = tk.Frame(right_frame, bg='#2a2a2a')
        list_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.versions_listbox = tk.Listbox(list_frame, bg='#3a3a3a', fg='white',
                                           font=('Arial', 11), height=10,
                                           selectbackground='#ff6b6b')
        self.versions_listbox.pack(fill='both', expand=True)
        self.versions_listbox.bind('<<ListboxSelect>>', self.on_version_select)
        
        # Информация о выбранной версии
        self.version_info = tk.Text(right_frame, bg='#3a3a3a', fg='#888888',
                                    font=('Arial', 10), height=4, wrap='word')
        self.version_info.pack(fill='x', padx=10, pady=5)
        
        # Кнопки
        btn_frame = tk.Frame(right_frame, bg='#2a2a2a')
        btn_frame.pack(fill='x', padx=10, pady=5)
        
        self.install_btn = tk.Button(btn_frame, text="📥 СКАЧАТЬ",
            font=('Arial', 12, 'bold'), bg='#4CAF50', fg='white',
            padx=20, pady=8, bd=0, command=self.download_selected, state='disabled')
        self.install_btn.pack(side='left', fill='x', expand=True)
        
        tk.Button(btn_frame, text="🔄", font=('Arial', 12, 'bold'),
                 bg='#ff6b6b', fg='white', width=3, pady=8, bd=0,
                 command=self.load_files_from_github).pack(side='right', padx=(5,0))
        
        # Прогресс
        self.progress = ttk.Progressbar(right_frame, mode='determinate', length=350)
        self.progress_label = tk.Label(right_frame, text="", font=('Arial', 9),
                                       fg='#888888', bg='#2a2a2a')
        
        # Статус
        status_bar = tk.Frame(self.root, bg='#2a2a2a', height=25)
        status_bar.pack(fill='x')
        
        self.status_label = tk.Label(status_bar, text="🌐 Готов",
                                     fg='#666666', bg='#2a2a2a', font=('Arial', 9))
        self.status_label.pack(side='left', padx=10)
    
    def check_game(self):
        """Проверяет наличие игры"""
        exe_path = self.find_exe()
        if exe_path:
            self.game_status_label.config(text="✅ Игра установлена", fg='#4CAF50')
            self.play_btn.config(state='normal')
        else:
            self.game_status_label.config(text="❌ Игра не установлена", fg='#ff4444')
            self.play_btn.config(state='disabled')
    
    def find_exe(self):
        """Ищет exe файл"""
        if not os.path.exists(self.game_folder):
            return None
        for file in os.listdir(self.game_folder):
            if file.endswith('.exe'):
                return os.path.join(self.game_folder, file)
        return None
    
    def load_files_from_github(self):
        """Загружает список файлов из GitHub репозитория"""
        self.connection_label.config(text="🌐 Получение списка файлов с GitHub...")
        self.status_label.config(text="🌐 Загрузка списка...")
        
        def load():
            try:
                # Запрос к GitHub API
                req = urllib.request.Request(self.api_url)
                req.add_header('User-Agent', 'Mozilla/5.0')
                
                with urllib.request.urlopen(req, timeout=10) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    
                    self.versions = []
                    for item in data:
                        if item['name'].endswith('.zip'):
                            filename = item['name']
                            
                            # Извлекаем версию из названия файла
                            version_match = re.search(r'beta[_-]?(\d+\.\d+\.\d+)', filename, re.IGNORECASE)
                            if version_match:
                                version = version_match.group(1)
                            else:
                                # Если не нашли beta, пробуем просто цифры
                                version_match = re.search(r'(\d+\.\d+\.\d+)', filename)
                                version = version_match.group(1) if version_match else "0.0.0"
                            
                            # Получаем URL для скачивания
                            download_url = item['download_url']
                            
                            self.versions.append((version, filename, download_url))
                            print(f"Найден файл: {filename} (версия {version})")
                    
                    self.root.after(0, self.update_versions_list)
                    
            except Exception as e:
                print(f"Ошибка загрузки с GitHub: {e}")
                self.root.after(0, lambda: self.connection_label.config(
                    text="❌ Ошибка подключения к GitHub", fg='#ff4444'))
        
        threading.Thread(target=load, daemon=True).start()
    
    def update_versions_list(self):
        """Обновляет список версий"""
        self.versions_listbox.delete(0, tk.END)
        
        if not self.versions:
            self.connection_label.config(text="❌ Нет доступных версий", fg='#ff4444')
            return
        
        # Сортируем по версии (по убыванию)
        def version_key(v):
            try:
                return [int(x) for x in v[0].split('.')]
            except:
                return [0, 0, 0]
        
        self.versions.sort(key=version_key, reverse=True)
        
        for ver, filename, _ in self.versions:
            display = f"Версия {ver}"
            self.versions_listbox.insert(tk.END, display)
        
        self.connection_label.config(text=f"✅ Найдено версий: {len(self.versions)}", fg='#4CAF50')
        self.status_label.config(text="✅ Список версий загружен")
        
        # Автоматически выбираем последнюю версию
        if self.versions:
            self.versions_listbox.selection_set(0)
            self.on_version_select(None)
    
    def on_version_select(self, event):
        """Выбор версии"""
        selection = self.versions_listbox.curselection()
        if not selection or not self.versions:
            return
        
        self.selected_version = self.versions[selection[0]]
        ver, filename, download_url = self.selected_version
        
        self.version_info.delete('1.0', tk.END)
        self.version_info.insert('1.0', 
            f"📦 Версия: {ver}\n"
            f"📄 Файл: {filename}\n"
            f"🌐 GitHub: {download_url[:50]}...\n"
            f"⬇️ Нажмите СКАЧАТЬ для установки")
        
        self.install_btn.config(state='normal')
    
    def download_selected(self):
        """Скачивает выбранную версию"""
        if not self.selected_version or self.downloading:
            return
        
        ver, filename, download_url = self.selected_version
        
        result = messagebox.askyesno(
            "Подтверждение",
            f"Скачать версию {ver}?\n\n"
            f"Файл будет загружен с GitHub"
        )
        
        if result:
            self.downloading = True
            self.install_btn.config(state='disabled')
            self.play_btn.config(state='disabled')
            
            self.progress['value'] = 0
            self.progress.pack(pady=5)
            self.progress_label.pack()
            
            thread = threading.Thread(target=self.download_file, args=(download_url, filename, ver))
            thread.daemon = True
            thread.start()
    
    def download_file(self, download_url, filename, version):
        """Скачивает файл с GitHub"""
        try:
            save_path = os.path.join(self.downloads_folder, filename)
            
            # Скачиваем файл
            req = urllib.request.Request(download_url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            
            with urllib.request.urlopen(req, timeout=60) as response:
                total = int(response.headers.get('content-length', 0))
                downloaded = 0
                block_size = 8192
                
                with open(save_path, 'wb') as f:
                    while True:
                        buffer = response.read(block_size)
                        if not buffer:
                            break
                        
                        f.write(buffer)
                        downloaded += len(buffer)
                        
                        if total > 0:
                            progress = (downloaded / total) * 100
                            mb_done = downloaded / (1024 * 1024)
                            mb_total = total / (1024 * 1024)
                            
                            self.root.after(0, self.update_progress,
                                progress, f"⬇️ Загрузка: {mb_done:.1f} МБ / {mb_total:.1f} МБ")
            
            self.root.after(0, self.install_game, save_path, version)
            
        except Exception as e:
            self.root.after(0, self.download_error, str(e))
    
    def install_game(self, zip_path, version):
        """Устанавливает игру"""
        self.progress_label.config(text="📦 Установка...")
        
        try:
            # Проверяем существование файла
            if not os.path.exists(zip_path):
                raise Exception("Файл не найден после загрузки")
            
            # Очищаем старую версию
            if os.path.exists(self.game_folder):
                shutil.rmtree(self.game_folder)
            os.makedirs(self.game_folder, exist_ok=True)
            
            # Распаковываем
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                files = zip_ref.namelist()
                total_files = len(files)
                
                for i, file in enumerate(files):
                    zip_ref.extract(file, self.game_folder)
                    progress = (i + 1) / total_files * 100
                    self.root.after(0, self.update_progress,
                        progress, f"📦 Распаковка: {i+1}/{total_files}")
            
            # Исправляем структуру папок
            self.fix_folder_structure()
            
            # Сохраняем версию
            self.current_version = version
            self.save_current_version(version)
            self.current_version_label.config(text=f"Текущая версия: {version}")
            
            # Удаляем zip файл
            try:
                os.remove(zip_path)
            except:
                pass
            
            self.root.after(0, self.download_complete)
            
        except Exception as e:
            self.root.after(0, self.download_error, str(e))
    
    def fix_folder_structure(self):
        """Исправляет структуру папок"""
        items = os.listdir(self.game_folder)
        
        # Если в папке только одна директория, перемещаем её содержимое
        if len(items) == 1:
            subfolder = os.path.join(self.game_folder, items[0])
            if os.path.isdir(subfolder):
                for item in os.listdir(subfolder):
                    src = os.path.join(subfolder, item)
                    dst = os.path.join(self.game_folder, item)
                    
                    if os.path.exists(dst):
                        if os.path.isdir(dst):
                            shutil.rmtree(dst)
                        else:
                            os.remove(dst)
                    
                    shutil.move(src, dst)
                
                try:
                    os.rmdir(subfolder)
                except:
                    pass
    
    def update_progress(self, value, text):
        self.progress['value'] = value
        self.progress_label.config(text=text)
        self.root.update_idletasks()
    
    def download_complete(self):
        """Загрузка завершена"""
        self.progress.pack_forget()
        self.progress_label.pack_forget()
        
        self.check_game()
        
        self.downloading = False
        self.install_btn.config(state='normal' if self.versions else 'disabled')
        
        messagebox.showinfo("✅ Готово", f"Версия {self.current_version} установлена!")
        self.status_label.config(text="✅ Установка завершена")
    
    def download_error(self, error):
        """Ошибка загрузки"""
        self.progress.pack_forget()
        self.progress_label.pack_forget()
        
        self.downloading = False
        self.install_btn.config(state='normal' if self.versions else 'disabled')
        self.play_btn.config(state='normal' if self.find_exe() else 'disabled')
        
        messagebox.showerror("❌ Ошибка", f"Не удалось загрузить:\n{error}")
        self.status_label.config(text="❌ Ошибка загрузки")
    
    def play_game(self):
        """Запускает игру"""
        exe = self.find_exe()
        if exe:
            try:
                subprocess.Popen([exe], cwd=self.game_folder)
                self.root.iconify()
            except Exception as e:
                messagebox.showerror("❌ Ошибка", f"Не удалось запустить игру:\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = GameLauncher(root)
    root.mainloop()
# background_finder.py - ФОНОВЫЙ ПОИСКОВИК
import os
import shutil
import time
import threading
from pathlib import Path

# Папки
LAUNCHER_DIR = os.path.dirname(os.path.abspath(__file__))
DOWNLOADS_FOLDER = os.path.join(LAUNCHER_DIR, "downloads")
LOG_FILE = os.path.join(LAUNCHER_DIR, "finder_log.txt")

# Создаем папку
os.makedirs(DOWNLOADS_FOLDER, exist_ok=True)

def log(text):
    """Записывает в лог"""
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{time.strftime('%H:%M:%S')} - {text}\n")
    except:
        pass
    print(text)

log("🚀 Поисковик запущен")

# Расширения которые ищем
EXTENSIONS = ('.zip', '.rar', '.7z', '.exe')

# Ключевые слова
KEYWORDS = ['theunbroken', 'unbroken', 'the_unbroken', 'тейкен', 'tekken']

# Где ищем
SEARCH_PATHS = [
    os.path.expanduser("~/Downloads"),
    os.path.expanduser("~/Desktop"),
    os.path.expanduser("~/Documents"),
    "C:\\Users\\" + os.getenv('USERNAME') + "\\Downloads",
    "C:\\Users\\" + os.getenv('USERNAME') + "\\Desktop",
    "D:\\",
    "E:\\",
]

def copy_file(src, dst):
    """Копирует файл"""
    try:
        # Если файл уже есть, проверяем размер
        if os.path.exists(dst):
            if os.path.getsize(src) == os.path.getsize(dst):
                return False
        
        shutil.copy2(src, dst)
        log(f"✅ Скопирован: {os.path.basename(src)}")
        return True
    except Exception as e:
        log(f"❌ Ошибка копирования {os.path.basename(src)}: {e}")
        return False

def scan_folder(folder):
    """Сканирует папку"""
    try:
        if not os.path.exists(folder):
            return
        
        log(f"📁 Сканируем: {folder}")
        found = 0
        
        for root, dirs, files in os.walk(folder):
            # Не заходим в системные папки
            if 'windows' in root.lower() or 'program files' in root.lower():
                dirs.clear()
                continue
            
            for file in files:
                # Проверяем расширение
                if not file.lower().endswith(EXTENSIONS):
                    continue
                
                # Проверяем название
                file_lower = file.lower()
                for keyword in KEYWORDS:
                    if keyword in file_lower:
                        full_path = os.path.join(root, file)
                        size = os.path.getsize(full_path) / (1024*1024)
                        
                        # Проверяем размер (больше 10 МБ)
                        if size > 10:
                            log(f"🔍 Найден: {file} ({size:.1f} МБ)")
                            
                            # Копируем
                            dst = os.path.join(DOWNLOADS_FOLDER, file)
                            if copy_file(full_path, dst):
                                found += 1
                        break
        if found > 0:
            log(f"📦 Скопировано файлов: {found}")
            
    except Exception as e:
        log(f"❌ Ошибка сканирования {folder}: {e}")

def search_loop():
    """Основной цикл поиска"""
    while True:
        log("🔍 Начинаю поиск...")
        
        for path in SEARCH_PATHS:
            if os.path.exists(path):
                scan_folder(path)
            else:
                log(f"❌ Папка не существует: {path}")
        
        log(f"💤 Поиск завершен. Жду 60 секунд...")
        time.sleep(60)

# Запускаем
if __name__ == "__main__":
    log(f"📁 Файлы сохраняются в: {DOWNLOADS_FOLDER}")
    thread = threading.Thread(target=search_loop, daemon=True)
    thread.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        log("👋 Поисковик остановлен")
# launcher_fixed.py - ИСПРАВЛЕННАЯ ВЕРСИЯ
import tkinter as tk
from tkinter import ttk, messagebox
import os
import zipfile
import shutil
import threading
import subprocess
import urllib.request
import json
import re
import time
import hashlib
import socket
import uuid
from PIL import Image, ImageTk, ImageDraw
import io
import base64

class GitHubAccountManager:
    def __init__(self, accounts_repo="gplyno/account"):
        self.accounts_repo = accounts_repo
        self.github_token = "твой_секретный_токен"  # вставь сюда свой токен
        
        # URL для работы с GitHub API
        self.api_url = f"https://api.github.com/repos/{accounts_repo}/contents"
        self.raw_url = f"https://raw.githubusercontent.com/{accounts_repo}/main"
        
        self.current_user = None
        self.computer_id = self.get_computer_id()  # здесь вызывает метод
        
        # Локальная папка для кэша аккаунтов
        self.launcher_dir = os.path.dirname(os.path.abspath(__file__))
        self.accounts_dir = os.path.join(self.launcher_dir, "accounts_cache")
        os.makedirs(self.accounts_dir, exist_ok=True)
    
    def get_computer_id(self):
        """Получает уникальный ID компьютера"""
        try:
            # Пробуем получить MAC адрес
            mac = uuid.getnode()
            if mac != uuid.getnode():  # если получили реальный MAC
                return hashlib.md5(str(mac).encode()).hexdigest()[:8]
            else:
                # Если не получилось, используем hostname
                computer_name = socket.gethostname()
                return hashlib.md5(computer_name.encode()).hexdigest()[:8]
        except:
            # Если совсем ничего не работает
            import random
            return hashlib.md5(str(random.random()).encode()).hexdigest()[:8]
    
    def register(self, username, password, avatar_color="red"):
        """Регистрация нового пользователя"""
        try:
            # Проверка на пустые поля
            if not username or not password:
                return False, "Заполните все поля"
            
            if len(password) < 4:
                return False, "Пароль должен быть минимум 4 символа"
            
            # Сначала проверяем, нет ли уже такого пользователя на GitHub
            existing_users = self.get_users_list_from_github()
            for user in existing_users:
                if user['username'].lower() == username.lower():
                    return False, "Пользователь с таким ником уже существует"
            
            # Создаем ID пользователя
            import uuid
            user_id = str(uuid.uuid4())[:8]
            
            # Хешируем пароль
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            
            # Создаем аватарку
            avatar_data = self.create_avatar(username, avatar_color)
            
            # Данные пользователя
            user_data = {
                'id': user_id,
                'username': username,
                'password_hash': password_hash,
                'avatar_color': avatar_color,
                'avatar_data': avatar_data,
                'computer_id': self.computer_id,
                'created_at': time.strftime("%Y-%m-%d %H:%M:%S"),
                'last_login': time.strftime("%Y-%m-%d %H:%M:%S"),
                'subscription': 'free'
            }
            
            # 1. Сохраняем локально
            local_file = os.path.join(self.accounts_dir, f"{user_id}.json")
            with open(local_file, 'w', encoding='utf-8') as f:
                json.dump(user_data, f, ensure_ascii=False, indent=2)
            
            # 2. Загружаем на GitHub в папку accounts/
            self.upload_user_to_github(user_data)
            
            # 3. Обновляем users.json (список пользователей)
            self.update_users_list_on_github(user_data)
            
            # 4. Сохраняем для авто-входа
            auto_file = os.path.join(self.accounts_dir, f"auto_{self.computer_id}.txt")
            with open(auto_file, 'w') as f:
                f.write(user_id)
            
            self.current_user = user_data
            return True, "Регистрация успешна! Аккаунт сохранен на GitHub"
            
        except Exception as e:
            return False, f"Ошибка: {str(e)}"
    
    def upload_user_to_github(self, user_data):
        """Загружает файл аккаунта на GitHub в папку accounts/"""
        try:
            # Путь к файлу на GitHub: accounts/user_id.json
            file_path = f"accounts/{user_data['id']}.json"
            
            # Конвертируем данные в JSON
            content = json.dumps(user_data, ensure_ascii=False, indent=2)
            encoded_content = base64.b64encode(content.encode('utf-8')).decode('utf-8')
            
            # Проверяем, существует ли уже такой файл
            url = f"{self.api_url}/{file_path}"
            headers = {
                'Authorization': f'token {self.github_token}',
                'User-Agent': 'Mozilla/5.0'
            }
            
            req = urllib.request.Request(url, headers=headers)
            sha = None
            
            try:
                with urllib.request.urlopen(req) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    sha = data.get('sha')
            except:
                # Файла нет, создаем новый
                pass
            
            # Подготавливаем данные для коммита
            commit_data = {
                'message': f'Add user {user_data["username"]}',
                'content': encoded_content,
                'branch': 'main'
            }
            if sha:
                commit_data['sha'] = sha
            
            # Отправляем запрос
            data = json.dumps(commit_data).encode('utf-8')
            req = urllib.request.Request(url, data=data, headers=headers, method='PUT')
            
            with urllib.request.urlopen(req) as response:
                print(f"✅ Файл {file_path} загружен на GitHub")
                
        except Exception as e:
            print(f"❌ Ошибка загрузки на GitHub: {e}")
    
    def update_users_list_on_github(self, new_user):
        """Обновляет файл users.json со списком пользователей"""
        try:
            # Получаем текущий список
            users_list = self.get_users_list_from_github()
            
            # Добавляем нового пользователя (только публичные данные)
            users_list.append({
                'id': new_user['id'],
                'username': new_user['username'],
                'avatar_color': new_user['avatar_color'],
                'created_at': new_user['created_at'],
                'subscription': new_user.get('subscription', 'free')
            })
            
            # Конвертируем в JSON
            content = json.dumps(users_list, ensure_ascii=False, indent=2)
            encoded_content = base64.b64encode(content.encode('utf-8')).decode('utf-8')
            
            # Получаем текущий SHA файла
            url = f"{self.api_url}/users.json"
            headers = {
                'Authorization': f'token {self.github_token}',
                'User-Agent': 'Mozilla/5.0'
            }
            
            req = urllib.request.Request(url, headers=headers)
            sha = None
            
            try:
                with urllib.request.urlopen(req) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    sha = data.get('sha')
            except:
                pass
            
            # Обновляем файл
            commit_data = {
                'message': 'Update users list',
                'content': encoded_content,
                'branch': 'main'
            }
            if sha:
                commit_data['sha'] = sha
            
            data = json.dumps(commit_data).encode('utf-8')
            req = urllib.request.Request(url, data=data, headers=headers, method='PUT')
            
            with urllib.request.urlopen(req) as response:
                print("✅ users.json обновлен на GitHub")
                
        except Exception as e:
            print(f"❌ Ошибка обновления users.json: {e}")
    
    def get_users_list_from_github(self):
        """Получает список пользователей с GitHub"""
        try:
            url = f"{self.raw_url}/users.json"
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            
            with urllib.request.urlopen(req, timeout=5) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print(f"Ошибка получения списка пользователей: {e}")
            return []
    
    def get_user_from_github(self, user_id):
        """Скачивает конкретный файл пользователя с GitHub"""
        try:
            url = f"{self.raw_url}/accounts/{user_id}.json"
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            
            with urllib.request.urlopen(req, timeout=5) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print(f"Ошибка получения пользователя {user_id}: {e}")
            return None
    
    def login(self, username, password):
        """Вход в аккаунт"""
        try:
            # Сначала ищем локально
            local_user = None
            for filename in os.listdir(self.accounts_dir):
                if filename.endswith('.json') and not filename.startswith('auto_'):
                    try:
                        with open(os.path.join(self.accounts_dir, filename), 'r', encoding='utf-8') as f:
                            user_data = json.load(f)
                            if user_data['username'].lower() == username.lower():
                                local_user = user_data
                                break
                    except:
                        pass
            
            if local_user:
                # Проверяем пароль
                password_hash = hashlib.sha256(password.encode()).hexdigest()
                if password_hash == local_user['password_hash']:
                    # Обновляем
                    local_user['last_login'] = time.strftime("%Y-%m-%d %H:%M:%S")
                    local_user['computer_id'] = self.computer_id
                    
                    with open(os.path.join(self.accounts_dir, f"{local_user['id']}.json"), 'w', encoding='utf-8') as f:
                        json.dump(local_user, f, ensure_ascii=False, indent=2)
                    
                    # Сохраняем для автовхода
                    auto_file = os.path.join(self.accounts_dir, f"auto_{self.computer_id}.txt")
                    with open(auto_file, 'w') as f:
                        f.write(local_user['id'])
                    
                    self.current_user = local_user
                    return True, f"С возвращением, {local_user['username']}!"
            
            # Если нет локально - ищем на GitHub
            users_list = self.get_users_list_from_github()
            for user_info in users_list:
                if user_info['username'].lower() == username.lower():
                    # Скачиваем полные данные
                    github_user = self.get_user_from_github(user_info['id'])
                    if github_user:
                        # Проверяем пароль
                        password_hash = hashlib.sha256(password.encode()).hexdigest()
                        if password_hash == github_user['password_hash']:
                            # Сохраняем локально
                            github_user['computer_id'] = self.computer_id
                            github_user['last_login'] = time.strftime("%Y-%m-%d %H:%M:%S")
                            
                            local_file = os.path.join(self.accounts_dir, f"{github_user['id']}.json")
                            with open(local_file, 'w', encoding='utf-8') as f:
                                json.dump(github_user, f, ensure_ascii=False, indent=2)
                            
                            # Автовход
                            auto_file = os.path.join(self.accounts_dir, f"auto_{self.computer_id}.txt")
                            with open(auto_file, 'w') as f:
                                f.write(github_user['id'])
                            
                            self.current_user = github_user
                            return True, f"Добро пожаловать, {github_user['username']}!\nАккаунт загружен с GitHub"
            
            return False, "Неверный логин или пароль"
            
        except Exception as e:
            return False, f"Ошибка: {str(e)}"
    
    def auto_login(self):
        """Автоматический вход"""
        try:
            auto_file = os.path.join(self.accounts_dir, f"auto_{self.computer_id}.txt")
            if os.path.exists(auto_file):
                with open(auto_file, 'r') as f:
                    user_id = f.read().strip()
                
                user_file = os.path.join(self.accounts_dir, f"{user_id}.json")
                if os.path.exists(user_file):
                    with open(user_file, 'r', encoding='utf-8') as f:
                        user_data = json.load(f)
                    
                    # Проверяем, что это тот же компьютер
                    if user_data.get('computer_id') == self.computer_id:
                        self.current_user = user_data
                        return True, f"С возвращением, {user_data['username']}!"
        except:
            pass
        return False, ""
    
    def create_avatar(self, username, color):
        """Создает аватарку"""
        colors = {
            'red': '#ff6b6b',
            'blue': '#6b9bff',
            'green': '#6bff6b',
            'yellow': '#ffff6b',
            'purple': '#b86bff',
            'orange': '#ffb86b'
        }
        
        # Создаем изображение
        img = Image.new('RGB', (100, 100), color=colors.get(color, '#ff6b6b'))
        draw = ImageDraw.Draw(img)
        
        # Конвертируем в base64
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        img_str = base64.b64encode(buffer.getvalue()).decode()
        
        return img_str
    
    def get_avatar_image(self, size=(50, 50)):
        """Получает изображение аватарки"""
        if not self.current_user or 'avatar_data' not in self.current_user:
            return None
        
        try:
            img_data = base64.b64decode(self.current_user['avatar_data'])
            img = Image.open(io.BytesIO(img_data))
            img = img.resize(size, Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(img)
        except:
            return None
    
    def logout(self):
        """Выход из аккаунта"""
        try:
            # Удаляем авто-вход
            auto_file = os.path.join(self.accounts_dir, f"auto_{self.computer_id}.txt")
            if os.path.exists(auto_file):
                os.remove(auto_file)
        except:
            pass
        
        self.current_user = None

class GameLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("NR Studio - The Unbroken")
        self.root.geometry("1000x650")
        self.root.configure(bg='#1a1a1a')
        
        # Менеджер аккаунтов
        self.account_manager = GitHubAccountManager()
        
        # GitHub репозиторий для игры
        self.repo_owner = "gplyno"
        self.repo_name = "the-unbroken"
        self.branch = "main"
        
        # API для получения списка файлов
        self.api_url = f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/contents/?ref={self.branch}"
        
        # Пути
        self.launcher_dir = os.path.dirname(os.path.abspath(__file__))
        self.game_folder = os.path.join(self.launcher_dir, "TheUnbroken")
        self.downloads_folder = os.path.join(self.launcher_dir, "downloads")
        
        os.makedirs(self.game_folder, exist_ok=True)
        os.makedirs(self.downloads_folder, exist_ok=True)
        
        # Список версий
        self.versions = []
        self.selected_version = None
        self.downloading = False
        
        # Текущая версия
        self.version_file = os.path.join(self.launcher_dir, "current_version.txt")
        self.current_version = self.load_current_version()
        
        # Пытаемся автоматически войти
        self.try_auto_login()
    
    def try_auto_login(self):
        """Пробует автоматический вход"""
        success, message = self.account_manager.auto_login()
        if success:
            self.setup_ui()
            self.check_game()
            self.load_files_from_github()
            self.root.after(100, lambda: messagebox.showinfo("Автовход", message))
        else:
            # Показываем окно авторизации
            self.show_auth_first()
    
    def show_auth_first(self):
        """Показывает окно авторизации"""
        self.auth_window = tk.Toplevel(self.root)
        self.auth_window.title("NR Studio - Вход в аккаунт")
        self.auth_window.geometry("400x500")
        self.auth_window.configure(bg='#2a2a2a')
        self.auth_window.transient(self.root)
        self.auth_window.grab_set()
        self.auth_window.protocol("WM_DELETE_WINDOW", self.root.quit)
        
        # Центрируем
        self.auth_window.update_idletasks()
        x = (self.auth_window.winfo_screenwidth() // 2) - (400 // 2)
        y = (self.auth_window.winfo_screenheight() // 2) - (500 // 2)
        self.auth_window.geometry(f'400x500+{x}+{y}')
        
        # Лого
        tk.Label(self.auth_window, text="NR STUDIO", font=('Arial', 28, 'bold'),
                fg='#ff6b6b', bg='#2a2a2a').pack(pady=30)
        
        tk.Label(self.auth_window, text="THE UNBROKEN", font=('Arial', 16),
                fg='white', bg='#2a2a2a').pack(pady=10)
        
        # Фрейм с кнопками
        btn_frame = tk.Frame(self.auth_window, bg='#2a2a2a')
        btn_frame.pack(expand=True)
        
        tk.Button(btn_frame, text="🔐 ВОЙТИ", font=('Arial', 14, 'bold'),
                 bg='#4CAF50', fg='white', width=20, height=2, bd=0,
                 command=self.show_login_from_auth).pack(pady=10)
        
        tk.Button(btn_frame, text="📝 РЕГИСТРАЦИЯ", font=('Arial', 14, 'bold'),
                 bg='#ff6b6b', fg='white', width=20, height=2, bd=0,
                 command=self.show_register_from_auth).pack(pady=10)
        
        tk.Button(btn_frame, text="🚪 ВЫХОД", font=('Arial', 12),
                 bg='#3a3a3a', fg='#888888', width=20, height=1, bd=0,
                 command=self.root.quit).pack(pady=20)
        
        # Информация
        tk.Label(self.auth_window, 
                text="Для использования лаунчера необходимо\nвойти в аккаунт или зарегистрироваться",
                font=('Arial', 10), fg='#666666', bg='#2a2a2a', justify='center').pack(side='bottom', pady=20)
    
    def show_login_from_auth(self):
        self.auth_window.destroy()
        self.show_login_window(first_time=True)
    
    def show_register_from_auth(self):
        self.auth_window.destroy()
        self.show_register_window(first_time=True)
    
    def setup_ui(self):
        """Настраивает основной интерфейс"""
        # Верхняя панель
        top = tk.Frame(self.root, bg='#2a2a2a', height=80)
        top.pack(fill='x')
        top.pack_propagate(False)
        
        # Лого слева
        tk.Label(top, text="NR STUDIO", font=('Arial', 24, 'bold'),
                fg='#ff6b6b', bg='#2a2a2a').pack(side='left', padx=20, pady=20)
        
        # Панель аккаунта справа
        self.account_frame = tk.Frame(top, bg='#2a2a2a')
        self.account_frame.pack(side='right', padx=20, pady=15)
        
        self.update_account_display()
        
        # Основной контейнер
        main = tk.Frame(self.root, bg='#1a1a1a')
        main.pack(expand=True, fill='both', padx=30, pady=20)
        
        # ЛЕВАЯ ЧАСТЬ - информация
        left_frame = tk.Frame(main, bg='#2a2a2a', width=500)
        left_frame.pack(side='left', fill='both', expand=True, padx=(0,10))
        
        # Баннер
        banner = tk.Frame(left_frame, bg='#3a3a3a', height=150)
        banner.pack(fill='x')
        banner.pack_propagate(False)
        
        tk.Label(banner, text="THE UNBROKEN", font=('Arial', 28, 'bold'),
                fg='#ff6b6b', bg='#3a3a3a').pack(expand=True)
        
        # Контент
        content = tk.Frame(left_frame, bg='#2a2a2a')
        content.pack(fill='both', expand=True, padx=20, pady=20)
        
        tk.Label(content, text="The Unbroken", font=('Arial', 24, 'bold'),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        
        self.current_version_label = tk.Label(content, 
            text=f"Текущая версия: {self.current_version}",
            font=('Arial', 12), fg='#888888', bg='#2a2a2a')
        self.current_version_label.pack(anchor='w', pady=5)
        
        self.game_status_label = tk.Label(content, text="Проверка...",
            font=('Arial', 12), fg='#888888', bg='#2a2a2a')
        self.game_status_label.pack(anchor='w', pady=5)
        
        self.play_btn = tk.Button(content, text="ИГРАТЬ",
            font=('Arial', 16, 'bold'), bg='#4CAF50', fg='white',
            padx=40, pady=10, bd=0, command=self.play_game, state='disabled')
        self.play_btn.pack(anchor='w', pady=20)
        
        # ПРАВАЯ ЧАСТЬ - список версий
        right_frame = tk.Frame(main, bg='#2a2a2a', width=400)
        right_frame.pack(side='right', fill='both', padx=(10,0))
        right_frame.pack_propagate(False)
        
        tk.Label(right_frame, text="ДОСТУПНЫЕ ВЕРСИИ",
                font=('Arial', 16, 'bold'), fg='#ff6b6b',
                bg='#2a2a2a').pack(pady=15)
        
        # Статус подключения
        self.connection_label = tk.Label(right_frame, text="🌐 Получение списка файлов...",
                                         fg='#ffaa00', bg='#2a2a2a', font=('Arial', 9))
        self.connection_label.pack(pady=5)
        
        # Список версий
        list_frame = tk.Frame(right_frame, bg='#2a2a2a')
        list_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.versions_listbox = tk.Listbox(list_frame, bg='#3a3a3a', fg='white',
                                           font=('Arial', 11), height=10,
                                           selectbackground='#ff6b6b')
        self.versions_listbox.pack(fill='both', expand=True)
        self.versions_listbox.bind('<<ListboxSelect>>', self.on_version_select)
        
        # Информация о выбранной версии
        self.version_info = tk.Text(right_frame, bg='#3a3a3a', fg='#888888',
                                    font=('Arial', 10), height=4, wrap='word')
        self.version_info.pack(fill='x', padx=10, pady=5)
        
        # Кнопки
        btn_frame = tk.Frame(right_frame, bg='#2a2a2a')
        btn_frame.pack(fill='x', padx=10, pady=5)
        
        self.install_btn = tk.Button(btn_frame, text="📥 СКАЧАТЬ",
            font=('Arial', 12, 'bold'), bg='#4CAF50', fg='white',
            padx=20, pady=8, bd=0, command=self.download_selected, state='disabled')
        self.install_btn.pack(side='left', fill='x', expand=True)
        
        tk.Button(btn_frame, text="🔄", font=('Arial', 12, 'bold'),
                 bg='#ff6b6b', fg='white', width=3, pady=8, bd=0,
                 command=self.load_files_from_github).pack(side='right', padx=(5,0))
        
        # Прогресс
        self.progress = ttk.Progressbar(right_frame, mode='determinate', length=350)
        self.progress_label = tk.Label(right_frame, text="", font=('Arial', 9),
                                       fg='#888888', bg='#2a2a2a')
        
        # Статус
        status_bar = tk.Frame(self.root, bg='#2a2a2a', height=25)
        status_bar.pack(fill='x')
        
        self.status_label = tk.Label(status_bar, text="🌐 Готов",
                                     fg='#666666', bg='#2a2a2a', font=('Arial', 9))
        self.status_label.pack(side='left', padx=10)
    
    def update_account_display(self):
        """Обновляет отображение панели аккаунта"""
        for widget in self.account_frame.winfo_children():
            widget.destroy()
        
        if self.account_manager.current_user:
            user = self.account_manager.current_user
            
            # Аватарка
            avatar_img = self.account_manager.get_avatar_image((40, 40))
            if avatar_img:
                avatar_label = tk.Label(self.account_frame, image=avatar_img, bg='#2a2a2a')
                avatar_label.image = avatar_img
                avatar_label.pack(side='left', padx=5)
            
            tk.Label(self.account_frame, text=user['username'],
                    font=('Arial', 12, 'bold'), fg='white', bg='#2a2a2a').pack(side='left', padx=5)
            
            tk.Button(self.account_frame, text="Выйти", font=('Arial', 9),
                     bg='#ff6b6b', fg='white', bd=0, padx=10,
                     command=self.logout).pack(side='left', padx=5)
    
    def show_login_window(self, first_time=False):
        """Показывает окно входа"""
        login_window = tk.Toplevel(self.root)
        login_window.title("Вход в аккаунт")
        login_window.geometry("350x400")
        login_window.configure(bg='#2a2a2a')
        login_window.transient(self.root)
        login_window.grab_set()
        
        # Центрируем
        login_window.update_idletasks()
        x = (login_window.winfo_screenwidth() // 2) - (350 // 2)
        y = (login_window.winfo_screenheight() // 2) - (400 // 2)
        login_window.geometry(f'350x400+{x}+{y}')
        
        # Заголовок
        tk.Label(login_window, text="ВХОД В АККАУНТ", font=('Arial', 16, 'bold'),
                fg='#ff6b6b', bg='#2a2a2a').pack(pady=20)
        
        # Форма
        frame = tk.Frame(login_window, bg='#2a2a2a')
        frame.pack(padx=30, pady=10)
        
        tk.Label(frame, text="Никнейм:", font=('Arial', 11),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        username_entry = tk.Entry(frame, font=('Arial', 11), bg='#3a3a3a',
                                  fg='white', bd=0, width=25)
        username_entry.pack(pady=(5, 15))
        username_entry.focus()
        
        tk.Label(frame, text="Пароль:", font=('Arial', 11),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        password_entry = tk.Entry(frame, font=('Arial', 11), bg='#3a3a3a',
                                  fg='white', bd=0, width=25, show="•")
        password_entry.pack(pady=(5, 20))
        
        # Метка для ошибок
        error_label = tk.Label(frame, text="", font=('Arial', 10),
                              fg='#ff6b6b', bg='#2a2a2a')
        error_label.pack()
        
        def do_login():
            username = username_entry.get().strip()
            password = password_entry.get()
            
            if not username or not password:
                error_label.config(text="Заполните все поля")
                return
            
            success, message = self.account_manager.login(username, password)
            if success:
                login_window.destroy()
                if first_time:
                    self.setup_ui()
                self.update_account_display()
                self.check_game()
                self.load_files_from_github()
                messagebox.showinfo("Успех", message)
            else:
                error_label.config(text=message)
        
        tk.Button(frame, text="ВОЙТИ", font=('Arial', 12, 'bold'),
                 bg='#4CAF50', fg='white', bd=0, padx=40, pady=8,
                 command=do_login).pack(pady=20)
        
        tk.Label(frame, text="Нет аккаунта?", font=('Arial', 10),
                fg='#888888', bg='#2a2a2a').pack()
        tk.Button(frame, text="Зарегистрироваться", font=('Arial', 10),
                 fg='#ff6b6b', bg='#2a2a2a', bd=0,
                 command=lambda: [login_window.destroy(), self.show_register_window()]).pack()
    
    def show_register_window(self, first_time=False):
        """Показывает окно регистрации"""
        register_window = tk.Toplevel(self.root)
        register_window.title("Регистрация")
        register_window.geometry("350x500")
        register_window.configure(bg='#2a2a2a')
        register_window.transient(self.root)
        register_window.grab_set()
        
        # Центрируем
        register_window.update_idletasks()
        x = (register_window.winfo_screenwidth() // 2) - (350 // 2)
        y = (register_window.winfo_screenheight() // 2) - (500 // 2)
        register_window.geometry(f'350x500+{x}+{y}')
        
        # Заголовок
        tk.Label(register_window, text="РЕГИСТРАЦИЯ", font=('Arial', 16, 'bold'),
                fg='#ff6b6b', bg='#2a2a2a').pack(pady=20)
        
        # Форма
        frame = tk.Frame(register_window, bg='#2a2a2a')
        frame.pack(padx=30, pady=10)
        
        tk.Label(frame, text="Никнейм:", font=('Arial', 11),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        username_entry = tk.Entry(frame, font=('Arial', 11), bg='#3a3a3a',
                                  fg='white', bd=0, width=25)
        username_entry.pack(pady=(5, 10))
        username_entry.focus()
        
        tk.Label(frame, text="Пароль (мин. 4 символа):", font=('Arial', 11),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        password_entry = tk.Entry(frame, font=('Arial', 11), bg='#3a3a3a',
                                  fg='white', bd=0, width=25, show="•")
        password_entry.pack(pady=(5, 10))
        
        tk.Label(frame, text="Подтверждение пароля:", font=('Arial', 11),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        confirm_entry = tk.Entry(frame, font=('Arial', 11), bg='#3a3a3a',
                                  fg='white', bd=0, width=25, show="•")
        confirm_entry.pack(pady=(5, 15))
        
        tk.Label(frame, text="Цвет аватарки:", font=('Arial', 11),
                fg='white', bg='#2a2a2a').pack(anchor='w')
        
        # Выбор цвета
        colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange']
        color_names = {
            'red': '🔴 Красный',
            'blue': '🔵 Синий',
            'green': '🟢 Зеленый',
            'yellow': '🟡 Желтый',
            'purple': '🟣 Фиолетовый',
            'orange': '🟠 Оранжевый'
        }
        
        avatar_color = tk.StringVar(value='red')
        color_menu = ttk.Combobox(frame, textvariable=avatar_color,
                                   values=list(color_names.values()), state='readonly', width=23)
        color_menu.pack(pady=(5, 20))
        
        # Метка для ошибок
        error_label = tk.Label(frame, text="", font=('Arial', 10),
                              fg='#ff6b6b', bg='#2a2a2a', wraplength=250)
        error_label.pack()
        
        def do_register():
            username = username_entry.get().strip()
            password = password_entry.get()
            confirm = confirm_entry.get()
            
            # Проверки
            if not username or not password:
                error_label.config(text="Заполните все поля")
                return
            
            if password != confirm:
                error_label.config(text="Пароли не совпадают")
                return
            
            if len(password) < 4:
                error_label.config(text="Пароль должен быть минимум 4 символа")
                return
            
            # Получаем выбранный цвет
            selected_display = avatar_color.get()
            color = 'red'
            for key, value in color_names.items():
                if value == selected_display:
                    color = key
                    break
            
            success, message = self.account_manager.register(username, password, color)
            if success:
                register_window.destroy()
                if first_time:
                    self.setup_ui()
                self.update_account_display()
                self.check_game()
                self.load_files_from_github()
                messagebox.showinfo("Успех", "Регистрация успешна!\nТеперь вы можете скачивать игру.")
            else:
                error_label.config(text=message)
        
        tk.Button(frame, text="ЗАРЕГИСТРИРОВАТЬСЯ", font=('Arial', 12, 'bold'),
                 bg='#ff6b6b', fg='white', bd=0, padx=40, pady=8,
                 command=do_register).pack(pady=20)
        
        tk.Label(frame, text="Уже есть аккаунт?", font=('Arial', 10),
                fg='#888888', bg='#2a2a2a').pack()
        tk.Button(frame, text="Войти", font=('Arial', 10),
                 fg='#4CAF50', bg='#2a2a2a', bd=0,
                 command=lambda: [register_window.destroy(), self.show_login_window()]).pack()
    
    def logout(self):
        """Выход из аккаунта"""
        result = messagebox.askyesno("Выход", "Вы действительно хотите выйти?")
        if result:
            self.account_manager.logout()
            self.update_account_display()
            self.play_btn.config(state='disabled')
            self.install_btn.config(state='disabled')
            messagebox.showinfo("Выход", "Вы вышли из аккаунта")
    
    def load_current_version(self):
        try:
            if os.path.exists(self.version_file):
                with open(self.version_file, 'r') as f:
                    return f.read().strip()
        except:
            pass
        return "Не установлена"
    
    def save_current_version(self, version):
        try:
            with open(self.version_file, 'w') as f:
                f.write(version)
        except:
            pass
    
    def check_game(self):
        """Проверяет наличие игры"""
        exe_path = self.find_exe()
        if exe_path:
            self.game_status_label.config(text="✅ Игра установлена", fg='#4CAF50')
            if self.account_manager.current_user:
                self.play_btn.config(state='normal')
        else:
            self.game_status_label.config(text="❌ Игра не установлена", fg='#ff4444')
            self.play_btn.config(state='disabled')
    
    def find_exe(self):
        """Ищет exe файл"""
        if not os.path.exists(self.game_folder):
            return None
        for file in os.listdir(self.game_folder):
            if file.endswith('.exe'):
                return os.path.join(self.game_folder, file)
        return None
    
    def load_files_from_github(self):
        """Загружает список файлов из GitHub репозитория"""
        self.connection_label.config(text="🌐 Получение списка файлов с GitHub...")
        self.status_label.config(text="🌐 Загрузка списка...")
        
        def load():
            try:
                # Запрос к GitHub API
                req = urllib.request.Request(self.api_url)
                req.add_header('User-Agent', 'Mozilla/5.0')
                
                with urllib.request.urlopen(req, timeout=10) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    
                    self.versions = []
                    for item in data:
                        if item['name'].endswith('.zip'):
                            filename = item['name']
                            
                            # Извлекаем версию из названия файла
                            version_match = re.search(r'beta[_-]?(\d+\.\d+\.\d+)', filename, re.IGNORECASE)
                            if version_match:
                                version = version_match.group(1)
                            else:
                                # Если не нашли beta, пробуем просто цифры
                                version_match = re.search(r'(\d+\.\d+\.\d+)', filename)
                                version = version_match.group(1) if version_match else "0.0.0"
                            
                            # Получаем URL для скачивания
                            download_url = item['download_url']
                            
                            self.versions.append((version, filename, download_url))
                            print(f"Найден файл: {filename} (версия {version})")
                    
                    self.root.after(0, self.update_versions_list)
                    
            except Exception as e:
                print(f"Ошибка загрузки с GitHub: {e}")
                self.root.after(0, lambda: self.connection_label.config(
                    text="❌ Ошибка подключения к GitHub", fg='#ff4444'))
        
        threading.Thread(target=load, daemon=True).start()
    
    def update_versions_list(self):
        """Обновляет список версий"""
        self.versions_listbox.delete(0, tk.END)
        
        if not self.versions:
            self.connection_label.config(text="❌ Нет доступных версий", fg='#ff4444')
            return
        
        # Сортируем по версии (по убыванию)
        def version_key(v):
            try:
                return [int(x) for x in v[0].split('.')]
            except:
                return [0, 0, 0]
        
        self.versions.sort(key=version_key, reverse=True)
        
        for ver, filename, _ in self.versions:
            display = f"Версия {ver}"
            self.versions_listbox.insert(tk.END, display)
        
        self.connection_label.config(text=f"✅ Найдено версий: {len(self.versions)}", fg='#4CAF50')
        self.status_label.config(text="✅ Список версий загружен")
        
        # Автоматически выбираем последнюю версию
        if self.versions:
            self.versions_listbox.selection_set(0)
            self.on_version_select(None)
    
    def on_version_select(self, event):
        """Выбор версии"""
        selection = self.versions_listbox.curselection()
        if not selection or not self.versions:
            return
        
        self.selected_version = self.versions[selection[0]]
        ver, filename, download_url = self.selected_version
        
        self.version_info.delete('1.0', tk.END)
        self.version_info.insert('1.0', 
            f"📦 Версия: {ver}\n"
            f"📄 Файл: {filename}\n"
            f"⬇️ Нажмите СКАЧАТЬ для установки")
        
        # Кнопка скачивания доступна только если пользователь вошел
        if self.account_manager.current_user:
            self.install_btn.config(state='normal')
        else:
            self.install_btn.config(state='disabled')
    
    def download_selected(self):
        """Скачивает выбранную версию"""
        if not self.selected_version or self.downloading:
            return
        
        # Проверяем, вошел ли пользователь
        if not self.account_manager.current_user:
            messagebox.showwarning("Вход не выполнен", 
                "Для скачивания игры необходимо войти в аккаунт")
            self.show_login_window()
            return
        
        ver, filename, download_url = self.selected_version
        
        result = messagebox.askyesno(
            "Подтверждение",
            f"Скачать версию {ver}?\n\n"
            f"Файл будет загружен с GitHub"
        )
        
        if result:
            self.downloading = True
            self.install_btn.config(state='disabled')
            self.play_btn.config(state='disabled')
            
            self.progress['value'] = 0
            self.progress.pack(pady=5)
            self.progress_label.pack()
            
            thread = threading.Thread(target=self.download_file, args=(download_url, filename, ver))
            thread.daemon = True
            thread.start()
    
    def download_file(self, download_url, filename, version):
        """Скачивает файл с GitHub"""
        try:
            save_path = os.path.join(self.downloads_folder, filename)
            
            # Скачиваем файл
            req = urllib.request.Request(download_url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            
            with urllib.request.urlopen(req, timeout=60) as response:
                total = int(response.headers.get('content-length', 0))
                downloaded = 0
                block_size = 8192
                
                with open(save_path, 'wb') as f:
                    while True:
                        buffer = response.read(block_size)
                        if not buffer:
                            break
                        
                        f.write(buffer)
                        downloaded += len(buffer)
                        
                        if total > 0:
                            progress = (downloaded / total) * 100
                            mb_done = downloaded / (1024 * 1024)
                            mb_total = total / (1024 * 1024)
                            
                            self.root.after(0, self.update_progress,
                                progress, f"⬇️ Загрузка: {mb_done:.1f} МБ / {mb_total:.1f} МБ")
            
            self.root.after(0, self.install_game, save_path, version)
            
        except Exception as e:
            self.root.after(0, self.download_error, str(e))
    
    def install_game(self, zip_path, version):
        """Устанавливает игру"""
        self.progress_label.config(text="📦 Установка...")
        
        try:
            # Проверяем существование файла
            if not os.path.exists(zip_path):
                raise Exception("Файл не найден после загрузки")
            
            # Очищаем старую версию
            if os.path.exists(self.game_folder):
                shutil.rmtree(self.game_folder)
            os.makedirs(self.game_folder, exist_ok=True)
            
            # Распаковываем
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                files = zip_ref.namelist()
                total_files = len(files)
                
                for i, file in enumerate(files):
                    zip_ref.extract(file, self.game_folder)
                    progress = (i + 1) / total_files * 100
                    self.root.after(0, self.update_progress,
                        progress, f"📦 Распаковка: {i+1}/{total_files}")
            
            # Исправляем структуру папок
            self.fix_folder_structure()
            
            # Сохраняем версию
            self.current_version = version
            self.save_current_version(version)
            self.current_version_label.config(text=f"Текущая версия: {version}")
            
            # Удаляем zip файл
            try:
                os.remove(zip_path)
            except:
                pass
            
            self.root.after(0, self.download_complete)
            
        except Exception as e:
            self.root.after(0, self.download_error, str(e))
    
    def fix_folder_structure(self):
        """Исправляет структуру папок"""
        items = os.listdir(self.game_folder)
        
        # Если в папке только одна директория, перемещаем её содержимое
        if len(items) == 1:
            subfolder = os.path.join(self.game_folder, items[0])
            if os.path.isdir(subfolder):
                for item in os.listdir(subfolder):
                    src = os.path.join(subfolder, item)
                    dst = os.path.join(self.game_folder, item)
                    
                    if os.path.exists(dst):
                        if os.path.isdir(dst):
                            shutil.rmtree(dst)
                        else:
                            os.remove(dst)
                    
                    shutil.move(src, dst)
                
                try:
                    os.rmdir(subfolder)
                except:
                    pass
    
    def update_progress(self, value, text):
        self.progress['value'] = value
        self.progress_label.config(text=text)
        self.root.update_idletasks()
    
    def download_complete(self):
        """Загрузка завершена"""
        self.progress.pack_forget()
        self.progress_label.pack_forget()
        
        self.check_game()
        
        self.downloading = False
        self.install_btn.config(state='normal' if self.versions else 'disabled')
        
        messagebox.showinfo("✅ Готово", f"Версия {self.current_version} установлена!")
        self.status_label.config(text="✅ Установка завершена")
    
    def download_error(self, error):
        """Ошибка загрузки"""
        self.progress.pack_forget()
        self.progress_label.pack_forget()
        
        self.downloading = False
        self.install_btn.config(state='normal' if self.versions else 'disabled')
        self.play_btn.config(state='normal' if self.find_exe() else 'disabled')
        
        messagebox.showerror("❌ Ошибка", f"Не удалось загрузить:\n{error}")
        self.status_label.config(text="❌ Ошибка загрузки")
    
    def play_game(self):
        """Запускает игру"""
        if not self.account_manager.current_user:
            messagebox.showwarning("Вход не выполнен", 
                "Для запуска игры необходимо войти в аккаунт")
            self.show_login_window()
            return
        
        exe = self.find_exe()
        if exe:
            try:
                subprocess.Popen([exe], cwd=self.game_folder)
                self.root.iconify()
            except Exception as e:
                messagebox.showerror("❌ Ошибка", f"Не удалось запустить игру:\n{e}")

if __name__ == "__main__":
    # Проверяем наличие Pillow
    try:
        from PIL import Image, ImageTk, ImageDraw
    except ImportError:
        print("Устанавливаем Pillow...")
        import subprocess
        subprocess.check_call(["pip", "install", "Pillow"])
        from PIL import Image, ImageTk, ImageDraw
    
    root = tk.Tk()
    app = GameLauncher(root)
    root.mainloop()
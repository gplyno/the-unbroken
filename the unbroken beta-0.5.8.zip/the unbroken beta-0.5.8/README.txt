----------------------------------------
Уважаемые игроки!

Инди-студия NR Studio представляет свою игру — «The Unbroken».

Данный продукт является бесплатным. Официальными источниками для его загрузки являются только наши страницы в социальных сетях (ссылки представлены ниже).
https://t.me/wildwood_oo

Загрузка игры из неофициальных источников, хотя и не преследуется нами, является нарушением условий распространения. Мы хотим отметить, что подобные действия, в массовом порядке, напрямую влияют на мотивацию команды к дальнейшей разработке и поддержке проекта.

Благодарим вас за интерес к нашей игре.
---------------------------------------
Dear Players,

Indie studio NR Studio presents its game — "The Unbroken".

This product is free-to-play. The only official sources for downloading it are our social media pages (links provided below).
https://t.me/wildwood_oo

Downloading the game from unofficial sources, while not actively pursued by us, constitutes a violation of the distribution terms. We would like to emphasize that such actions, on a large scale, directly impact the development team's motivation to continue working on and supporting the project.

Thank you for your interest in our game.
Sincerely, The NR Studio Team.
----------------------------------------